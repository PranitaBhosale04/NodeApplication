import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(public router:Router,public http: HttpClient) 
  { }
  
  // Logout(){
  //   sessionStorage.setItem("isloggedIn", "0");
  //   this.router.navigate(['/signIn']);
  // }


  
 

 
  DeleteData(user)
  {
    console.log("id in service"+user)
    return this.http.delete("http://localhost:53581/api/User/" + user);
  }

  DeleteMember(user)
  {
    console.log("id in service"+ user)
    return this.http.delete("http://localhost:53581/api/Family/" + user);
  }

  
  updatestatus(ID,status)
  {
    var object = { "Status":status }
    return this.http.put("http://localhost:53581/api/Complaint/"+ ID,object);
  }

  
}
