import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-all-customers',
  templateUrl: './all-customers.component.html',
  styleUrls: ['./all-customers.component.css']
})
export class AllCustomersComponent implements OnInit {
  customers:any;
  constructor(private router4: Router,private cCustomer:CustomerService) { }

  ngOnInit() 
  {
    
  }

 allCustomer()
 {
  let resp=this.cCustomer.getAllCustomers();
  resp.subscribe((data)=>this.customers=data);
 }

 sendReq(user_id:any)
 {
  this.router4.navigate(['/admin']);
  alert(user_id+"user reuest recieved");
 }


}
