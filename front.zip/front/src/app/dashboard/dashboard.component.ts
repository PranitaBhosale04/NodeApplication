import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  a: any;
  b: any;
  c: string;

  constructor(public router:Router) { }

  ngOnInit() {
    
    // this.a = sessionStorage.getItem("Name");
    // this.b = sessionStorage.getItem("userid");
    // this.c = sessionStorage.getItem("UserId");
    // if(this.b == null && this.a == null &&  this.c == null || this.c != "1")
    // {
    //    this.router.navigate(["/login"]);
    // }
  }
  
  Logout()
  {
    // delete sessionStorage["Name"];
    // delete sessionStorage["UserId"];
    // delete sessionStorage["userid"];
    this.router.navigate(["/login"]);
  }

}
