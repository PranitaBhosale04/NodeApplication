import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customerbyid',
  templateUrl: './customerbyid.component.html',
  styleUrls: ['./customerbyid.component.css']
})
export class CustomerbyidComponent implements OnInit {
  customer:any;
  constructor(private cService:CustomerService) { }

  ngOnInit(): void {
  }

  getCustomer(user_id)
  {
    this.cService.getCustomerById(user_id).subscribe((x)=>{this.customer=x});
  }

  getByName(name)
  {
    this.cService.getCustomerByName(name).subscribe((x)=>{this.customer=x});
  }
  getByCity(city)
  {
    this.cService.getCustomerByCity(city).subscribe((x)=>{this.customer=x});
  }
  getByOccu(occu)
  {
    this.cService.getCustomerByOccupation(occu).subscribe((x)=>{this.customer=x});
  }

}
