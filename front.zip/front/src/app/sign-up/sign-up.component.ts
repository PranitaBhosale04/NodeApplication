import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  message: string;
  data:any;
  submitted: boolean;
 
   constructor(public router : Router, public Service: RegisterService) { }
 
   ngOnInit() {
   }
   
  
  Register(RegisterForm:any)
  {
    let data= RegisterForm.form.value;
    this.Service.Register(data).subscribe(()=>
    {
        window.alert("Successfully Added");
    })
  }

  
  
 }
 
