import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(public router:Router) {
    if(1 == 1)
    this.router.navigate[('/home')];
   }

  ngOnInit() {
   
  }
  Logout()
  {
    // delete sessionStorage["Name"];
    // delete sessionStorage["UserId"];
    // delete sessionStorage["userid"];
    this.router.navigate(["/login"]);
  }


}
