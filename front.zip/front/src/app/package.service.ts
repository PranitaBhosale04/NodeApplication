import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PackageService {
  // addDelete(pkg_id: any) {
  //   throw new Error('Method not implemented.');
  // }

  constructor(private httpclient:HttpClient) 
  { }

  getPackage(){
    return this.httpclient.get("http://localhost:9090/getAll")
  }

  getPackageById(id){
    return this.httpclient.get("http://localhost:9090/getPkg"+id)
  }

  insertPackage1(data:any)
  {
  return this.httpclient.post("http://localhost:9090/insertPkg" ,data);
  }
  updatePackage1(pkg_id,p:any)
  {
    return this.httpclient.put("http://localhost:9090/updatePkg?pkg_id="+pkg_id,p);
  }

  deletePackage1(pkg_id)
  {
    console.log(pkg_id);
    return this.httpclient.delete("http://localhost:9090/deletePkg?pkg_id="+pkg_id);
  }



  insertPackage(pkg_name: string, amount: number, validity: number,extra_charges:number) {
    // add the token in the request headerv_company_name
    const httpOptions = {
     headers: new HttpHeaders({
       // token: sessionStorage['token']
     })
   }
 
 
   const body = {
    pkg_name: pkg_name,
    amount: amount,
    validity:validity,
    extra_charges : extra_charges
     
   }
   console.log(`${body.amount}body  from package`)
    
   
   return this.httpclient.post("http://localhost:9090/insertPkg" ,body, httpOptions)
 }

  updatePackage(pkg_id:number, pkg_name: string, amount: number, validity: number,extra_charges:number) 
  {
    // add the token in the request header

    console.log(pkg_id+"package id")
    const httpOptions = {
     headers: new HttpHeaders({
      //  token: sessionStorage['token']
     })
   };

   const body = {
    pkg_id:pkg_id,
    pkg_name: pkg_name,
    amount: amount,
    validity:validity,
    extra_charges : extra_charges
    
   }
   alert("updated..!!");
   return this.httpclient.put("http://localhost:9090/updatePkg", body, httpOptions)
 }

  addDelete(id){
    return this.httpclient.delete("http://localhost:9090/deletePkg"+id)
  }
  
}
