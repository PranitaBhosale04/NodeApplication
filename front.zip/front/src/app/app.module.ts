import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Http, HttpModule } from '@Angular/http';
import { LoginService } from './login.service';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { UserComponent } from './user/user.component';
import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";
import { AllCustomersComponent } from './all-customers/all-customers.component';
import { CustomerbyidComponent } from './customerbyid/customerbyid.component';
import { InsertCustomerComponent } from './insert-customer/insert-customer.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminComponent } from './admin/admin.component';
import { AddpackageComponent } from './addpackage/addpackage.component';
import { PackageComponent } from './package/package.component';
import { SelectPkgComponent } from './select-pkg/select-pkg.component';
import { ApkgComponent } from './apkg/apkg.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    AboutUsComponent,
    ContactUsComponent,
    SignUpComponent,
    UserComponent,  
    AllCustomersComponent, 
    CustomerbyidComponent, 
    InsertCustomerComponent, 
    AdminLoginComponent,  
    AdminComponent, AddpackageComponent, PackageComponent, SelectPkgComponent, ApkgComponent,
  ],
  imports: [
    BrowserModule,
   HttpClientModule,
   TranslateModule.forRoot({
    loader: {
      provide: TranslateLoader,
      useFactory: translateHttpLoaderFactory,
      deps: [HttpClient]
    }
  }),
    HttpModule,
    FormsModule,
    RouterModule.forRoot([
      
      {path :'login',component:LoginComponent},
      {path:'dashboard',component:DashboardComponent},
      {path:'register',component:SignUpComponent},
      {path:'footer', component:FooterComponent},
      {path:'all-customers', component:AllCustomersComponent},
      {path:'aboutus', component:AboutUsComponent},
      {path:'contactus',component:ContactUsComponent},
      {path:'list', component:UserComponent},
      {path:'contact-us',component:ContactUsComponent},
      {path:'insert-customer',component:InsertCustomerComponent},
      {path:'customerbyid',component:CustomerbyidComponent},
      {path:'admin',component:AdminComponent},
      {path:'admin-login',component:AdminLoginComponent},
      {path:'addpackage',component:AddpackageComponent},
      {path:'package',component:PackageComponent},
      {path:'apkg',component:ApkgComponent},
      {path:'**', component:HomeComponent}
      
    ])

  ],
  providers: [LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
export function translateHttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
