import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(public router:Router,public http:HttpClient)
  {

  } 
  Login(credentials:any)
  {
    console.log(credentials.name);
    return this.http.get("http://localhost:9090/api/UserRegistration/login?name="+`${credentials.name}`+"&password="+`${credentials.password}`);
  }

  adminLogin(credentials:any)
  {
    console.log(credentials.name);
    //return this.http.get("http://localhost:9090/login?name="+`${admin}`+"&password="+`${pass123}`);
    return this.http.get("http://localhost:9090/adminLogin?name="+`${credentials.name}`+"&password="+`${credentials.password}`);
  }

}


