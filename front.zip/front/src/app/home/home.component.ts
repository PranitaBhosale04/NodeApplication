import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  cnt:number;
  Service: any;
  constructor() { }

  ngOnInit()
  {
    this.count();
  }

  count()
  {
     /*this.Service.count().subscribe(()=>
     {
       alert(this.cnt);

     })*/
     this.Service.count().subscribe(()=>{this.cnt});
  }


}
