import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(public router:Router,public http:HttpClient)
  {

  } 
  //register(credentials:any)
  //{
    
  //  return this.http.post("http://localhost:53581/api/User/Registration",credentials);
  //}

  Register(data:any)
  {
    console.log(data);
    return this.http.post("http://localhost:9090/api/UserRegistration/save",data );
  }


  count()
  {
    return this.http.get("http://localhost:9090/api/UserRegistration/count");
  }

}


