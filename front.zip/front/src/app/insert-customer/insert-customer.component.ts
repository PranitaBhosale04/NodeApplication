import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-insert-customer',
  templateUrl: './insert-customer.component.html',
  styleUrls: ['./insert-customer.component.css']
})
export class InsertCustomerComponent implements OnInit {
  customer:Customer=new Customer(0,"","",0,"","","","","","",0,"",new Date(""),"","","","","",0,0);
  message:any;
  cust_id: number;
  submitted = false;
  public customerfile:any=File;
  constructor(private route: ActivatedRoute,private router: Router,private cService:CustomerService) { }

  ngOnInit() {
  }
  newCustomer(): void {
    this.submitted = false;
    this.customer = new Customer(0,"","",0,"","","","","","",0,"",new Date(""),"","","","","",0,0);
  }

  public insertDetails()
  {
    let resp=this.cService.insertCustDetails(this.customer);
    resp.subscribe((data)=>this.message=data);
  }

  /*insertDetails(InsertDetailsForm:any)
  {
    let data= InsertDetailsForm.form.value;
    this.cService.insertCustDetails(this.customer).subscribe(()=>
    {
    alert("Data Inserted successfully..!!!");
  });*/

 
    getCustomer(user_id)
    {
    this.cService.getCustomerById(user_id).subscribe((x)=>{this.message=x});
    }


      onSubmit(user_id) {
       
        this.submitted = true;
        //this.insertDetails;
        this.cService.getCustomerById(user_id).subscribe((x)=>{this.message=x});
       
      }
}
