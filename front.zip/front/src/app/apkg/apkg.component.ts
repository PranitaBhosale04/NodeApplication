import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PackageService } from '../package.service';
import { Packge } from '../packge';

@Component({
  selector: 'app-apkg',
  templateUrl: './apkg.component.html',
  styleUrls: ['./apkg.component.css']
})
export class ApkgComponent implements OnInit {

  packages :any=[]
  pkg_id: number;
  package: Packge;


  pkg:any;

  pkg_name=" "
  amount=0
  validity=0
  extra_charges=0

  id=null
 /*   {"Id":1,"Package_Name":"Copper","Package_Amount":"1200", "Package_Validity":"20/01/2021", "Package_Extra_Charges":50},
    {"Id":2,"Package_Name":"Silver","Package_Amount":"1500", "Package_Validity":"25/01/2021", "Package_Extra_Charges":100},
    {"Id":3,"Package_Name":"Gold","Package_Amount":"2000", "Package_Validity":"02/02/2021", "Package_Extra_Charges":150},
   ]*/

  constructor(private activatedRoute: ActivatedRoute,private router3: Router,private packageservice2:PackageService) { }

  ngOnInit() {
    this.packageservice2.getPackage().subscribe(res=>{
      this.packages=res

      console.log(res);
  });
}

  getPackage()
  {
    this.packageservice2.getPackage().subscribe((x)=>{this.packages=x});
  }

  onEdit() {
    /*
    this.packageservice2.updatePackage1(this.pkg_id, this.packages)
      .subscribe(data => {
        console.log(data);
        this.packages = new Packge(0,"",0,0,0);
        this.gotoList();
      }, error => console.log(error));
    }

      onSubmit() {
        this.onEdit;    
      }
    
      gotoList() {
        this.router3.navigate(['/addpackage']);
      }*/

      console.log(this.pkg +" onupdate")
    
    if (this.pkg>0)
    {
      // edit
     console.log(this.pkg +"onupdate")
       // alert("inside onupdate");
      this.packageservice2
        .updatePackage(this.id, this.pkg_name, this.amount, this.validity,this.extra_charges)
        .subscribe(response => 
          {
          // console.log(response)
          this.pkg_name=this.pkg['pkg_name']
          this.amount=this.pkg['amount']
          this.validity=this.pkg['validity']
          this.extra_charges=this.pkg['extra_charges']
          console.log(this.pkg[`extra_charges`]+"xyz")
         // console.log(this.pkg['pkg_id']+"Package id update")
        // console.log("inside onupdate");
            this.router3.navigate(['/addpackage'])
        })
    }
    else 
    {
      // insert
      this.packageservice2
        .insertPackage(this.pkg_name, this.amount, this.validity,this.extra_charges)
        .subscribe(response => {

            console.log("Package added successfully...!!!!");
            this.router3.navigate(['/addpackage'])
        })
      }
    }
    
  
 onDelete(pkg_id:number)
 {
      let resp= this.packageservice2.deletePackage1(pkg_id);
      resp.subscribe((data)=>{this.packages=data});
     
  }

}
