import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApkgComponent } from './apkg.component';

describe('ApkgComponent', () => {
  let component: ApkgComponent;
  let fixture: ComponentFixture<ApkgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApkgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApkgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
