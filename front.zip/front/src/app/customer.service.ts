import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  

  constructor(private http:HttpClient) { }

  getCustomerById(user_id)
  {
    return this.http.get("http://localhost:9090/getCustomer?user_id="+user_id);
  }
  getCustomerByName(name)
  {
    return this.http.get("http://localhost:9090/getCustomerByName?name="+name);
  }
  getCustomerByCity(city)
  {
    return this.http.get("http://localhost:9090/getCustomerByCity?city="+city);
  }
  getCustomerByOccupation(occu)
  {
    return this.http.get("http://localhost:9090/getCustomerByOccu?occu="+occu);
  }

  insertCustDetails(customer)
  {
   // console.log(data);
    return this.http.post("http://localhost:9090/insertCust",customer,{responseType:'text' as 'json'});
  // return this.http.post("http://localhost:9090/insertCust",data);
  }


  getAllCustomers()
  {
    console.log("done");
    return this.http.get("http://localhost:9090/allCustomer");
  }

  updateCustomer(cust_id,c:any)
  {
    return this.http.get("http://localhost:9090/updateCust?cust_id="+cust_id,c);
  }

  deleteCust(user_id)
  {

    return this.http.delete("http://localhost:9090/deleteCust?user_id="+user_id);
  }
}
