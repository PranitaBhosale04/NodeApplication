import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PackageService } from '../package.service';

@Component({
  selector: 'app-package',
  templateUrl: './package.component.html',
  styleUrls: ['./package.component.css']
})
export class PackageComponent implements OnInit {


  packages :any=[]

  pkg:any;

  pkg_name=" "
  amount=0
  validity=0
  extra_charges=0

  id=null
 /*   {"Id":1,"Package_Name":"Copper","Package_Amount":"1200", "Package_Validity":"20/01/2021", "Package_Extra_Charges":50},
    {"Id":2,"Package_Name":"Silver","Package_Amount":"1500", "Package_Validity":"25/01/2021", "Package_Extra_Charges":100},
    {"Id":3,"Package_Name":"Gold","Package_Amount":"2000", "Package_Validity":"02/02/2021", "Package_Extra_Charges":150},
   ]*/

  constructor(private activatedRoute: ActivatedRoute,private router3: Router,private packageservice1:PackageService) { }

  ngOnInit() {
    this.packageservice1.getPackage().subscribe(res=>{
      this.packages=res

      console.log(res);
  });
}


/* addpackage()
  {
    this.router3.navigate(['/addpackage'])
  }
  onEdit(pkg)
{
   this.router3.navigate(['/addpackage'],{queryParams:{id:pkg['pkg_id']}})

}

  onDelete(pkg){
    this.packageservice.addDelete(pkg.pkg_id).subscribe(res=>{
      console.log('package deleted')
    });
  } */

  getPackage()
  {
    this.packageservice1.getPackage().subscribe((x)=>{this.packages=x});
  }

  insertDetails1(InsertPkgForm:any)
  {
    let data= InsertPkgForm.form.value;
    this.packageservice1.insertPackage1(data).subscribe(()=>
    {
    alert("Data Inserted successfully..!!!");
  });
  }
 onDelete(pkg_id:number)
 {
      let resp= this.packageservice1.deletePackage1(pkg_id);
      resp.subscribe((data)=>{this.packages=data});
     
  }


}
