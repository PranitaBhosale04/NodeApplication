import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { PackageService } from '../package.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  custs:any;
  constructor(private activatedRoute: ActivatedRoute,private cService:CustomerService,private router3: Router,private packageservice:PackageService) { }
 // constructor(private cService:CustomerService) { }

  public delteCustomer(user_id:number){
    let resp= this.cService.deleteCust(user_id);
    resp.subscribe((data)=>this.custs=data);
   }


  ngOnInit() {
    let resp=this.cService.getAllCustomers();
    resp.subscribe((data)=>this.custs=data);
  }

}
