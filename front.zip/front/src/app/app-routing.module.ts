import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddpackageComponent } from './addpackage/addpackage.component';
import { AdminComponent } from './admin/admin.component';
import { AllCustomersComponent } from './all-customers/all-customers.component';
import { ApkgComponent } from './apkg/apkg.component';
import { CustomerbyidComponent } from './customerbyid/customerbyid.component';
import { InsertCustomerComponent } from './insert-customer/insert-customer.component';
import { PackageComponent } from './package/package.component';


const routes: Routes = [ 
     {path:"",redirectTo:"registercust",pathMatch:"full"},
     {path:"registercust",component:InsertCustomerComponent},
     {path:"all-customers",component:AllCustomersComponent},
     {path:"searchcust",component:CustomerbyidComponent},
     {path:"admin",component:AdminComponent},
     {path:'package',component:PackageComponent},
     {path:'addpackage',component:AddpackageComponent},
     {path:'apkg',component:ApkgComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
