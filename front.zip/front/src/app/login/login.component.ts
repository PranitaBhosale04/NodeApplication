import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  id
  username:string='';
  Password:string='';
  message: string;
 data:any;
 submitted = false;
 IsLoggedIn = false;
  Result: any;
  constructor(public router : Router,public Service:LoginService,private translateService: TranslateService) { 
   // translateService.addLangs(["en", "ge", "hi"]);
   // translateService.setDefaultLang("en");
  }

  ngOnInit() {

    sessionStorage.clear();
  }

  
 /* switchLanguage(language: string) {
    this.translateService.use(language);
  }*/
  
  Login(myForm)
  {
    
    let data=this.Service.Login(myForm.form.value);
    data.subscribe((res:any)=>
    {       
      console.log(res);
      this.Result = res;
     // console.log("inside login "+res.Data.RoleId);
      
      if(res.Status='Success')
      {
       // this.message="Login Successfull!!!";
        //console.log(res.error);
        alert("User Login successfull");
        // let sessionId = this.Result.Data.RoleId;
        // sessionStorage.setItem("UserId",sessionId);
        
        // let sessionName = this.Result.Data.Name;
        // sessionStorage.setItem("Name",sessionName);

        // let UID = this.Result.Data.UserId;
        // sessionStorage.setItem("userid",UID);

        // console.log("User id in login is " + UID )

        // if(res.Data.RoleId == 1)
        // {
          
        //   this.router.navigate(['/dashboard']);
        // }
        // else
        // { 
        //   this.router.navigate(['/dashboardowner']);

        // }
        // if(data!=null)
        // {
        //   this.submitted=true;
        //   this.IsLoggedIn = true;
         

          //this.router.navigate(['/all-customers']);
            this.router.navigate(['/insert-customer']);
        // }
      }
      else
      {
        this.message="Something is Wrong";
      }

    });
  }

  
}
