export class Customer{

    cust_id:number;
    name:String;
    image:String;
    pkg_id:number;
    status:String;
    religion:String;
    cast:String;
    zodiac:String;
    occupation:String;
    education:String;
    income:number;
    blood_group:String;
    birth_date:Date;
    contact2:String;
    state:String;
    district:String;
    city:String;
    street_name:string;
    pincode:number;
    notification:number;

    constructor(
        cust_id:number,
        name:String,
        image:String,
        pkg_id:number,
        status:String,
        religion:String,
        cast:String,
        zodiac:String,
        occupation:String,
        education:String,
        income:number,
        blood_group:String,
        birth_date:Date,
        contact2:String,
        state:String,
        district:String,
        city:String,
        street_name:string,
        pincode:number,
        notification:number)
        {

        }


}