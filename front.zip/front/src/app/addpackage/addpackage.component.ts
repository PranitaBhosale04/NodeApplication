import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PackageService } from '../package.service';
import { Packge } from '../packge';

@Component({
  selector: 'app-addpackage',
  templateUrl: './addpackage.component.html',
  styleUrls: ['./addpackage.component.css']
})
export class AddpackageComponent implements OnInit 
{
  package:Packge=new Packge(0,"",0,0,0);
  message:any;
  packages :any=[]


  pkg:any;

  pkg_name=" "
  amount=0
  validity=0
  extra_charges=0

  id=null
 /*   {"Id":1,"Package_Name":"Copper","Package_Amount":"1200", "Package_Validity":"20/01/2021", "Package_Extra_Charges":50},
    {"Id":2,"Package_Name":"Silver","Package_Amount":"1500", "Package_Validity":"25/01/2021", "Package_Extra_Charges":100},
    {"Id":3,"Package_Name":"Gold","Package_Amount":"2000", "Package_Validity":"02/02/2021", "Package_Extra_Charges":150},
   ]*/

  constructor(private activatedRoute: ActivatedRoute,private router3: Router,private packageservice:PackageService) { }

  ngOnInit() {
    this.packageservice.getPackage().subscribe(res=>{
      this.packages=res

      console.log(res);
  });
}

  getPackage()
  {
    this.packageservice.getPackage().subscribe((x)=>{this.packages=x});
  }

  insertDetails1(InsertPkgForm:any)
  {
      let resp=this.packageservice.insertPackage1(this.package);
      resp.subscribe((data)=>this.message=data);
  }
  

 /* pkg_name=" "
  amount=0
  validity=0
  extra_charges=0

  id=null
  pkg: number;
  
  constructor(private activatedRoute:ActivatedRoute,private packageservice:PackageService, private router2:Router) { }

  ngOnInit(): void {
    let id = this.activatedRoute.snapshot.queryParams['id']
   this.id=id
  console.log(id +'id')
  
   if (id>0) {
    // edit product
    this.packageservice
      .getPackageById(id)
      .subscribe(response => {
         if (response) {
       
        this.pkg_name=response['pkg_name']
        this.amount=response['amount']
        this.validity=response['validity']
        this.extra_charges=response['extra_charges']
      
           const packages = response
           this.pkg=1
    
         }
      })
   }
}



   onUpdate()
   {
     console.log(this.pkg +" onupdate")
    
    if (this.pkg>0)
    {
      // edit
     console.log(this.pkg +"onupdate")
       // alert("inside onupdate");
      this.packageservice
        .updatePackage(this.id, this.pkg_name, this.amount, this.validity,this.extra_charges)
        .subscribe(response => 
          {
          // console.log(response)
          this.pkg_name=this.pkg['pkg_name']
          this.amount=this.pkg['amount']
          this.validity=this.pkg['validity']
          this.extra_charges=this.pkg['extra_charges']
          console.log(this.pkg[`extra_charges`]+"xyz")
         // console.log(this.pkg['pkg_id']+"Package id update")
        // console.log("inside onupdate");
            this.router2.navigate(['/package'])
        })
    }
    else 
    {
      // insert
      this.packageservice
        .insertPackage(this.pkg_name, this.amount, this.validity,this.extra_charges)
        .subscribe(response => {

            console.log("Package added successfully...!!!!");
            this.router2.navigate(['/package'])
        })
    }*/
    
 }

  
 


