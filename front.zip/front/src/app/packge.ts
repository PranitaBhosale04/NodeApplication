export class Packge
{
    pkg_id:number;
    pkg_name:string;
    validity:number;
    amount:number;
    extra_charges:number;

    constructor(pkg_id:number,
        pkg_name:string,
        validity:number,
        amount:number,
        extra_charges:number)
        {

        }
}