import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  Service: any;
  Result: any;
  router: any;
  id
  username:string='';
  password:string='';
  message: string;
 data:any;
 submitted = false;
 IsLoggedIn = false;
 
  constructor(public router1 : Router,public Service1:LoginService,private translateService: TranslateService) { }

  ngOnInit() {
  }

 public adminLogin(myAdminForm)
  {
    let data=this.Service1.adminLogin(myAdminForm.form.value);
    
   data.subscribe((res:any)=>
    {       
      console.log(res);
      this.Result = res;
      alert("admin login successfull ");
      this.router1.navigate(['/admin']);
    });
  
   /* if(this.data.username=="admin" && this.data.password=="admin123"){   
      this.router.navigate(['/admin']);
    }
    else{
      window.alert("Wrong Username Password");
    }*/

  }

  ForgotPassword()
  {
    this.router.navigate(['/forgotpassword']);
  }
}
