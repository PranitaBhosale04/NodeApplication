import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
userlist;
  message: string;
  constructor(public service:UserService,public router:Router) { }

  ngOnInit() {
    
  }


Delete(user)
{
  console.log("delete "+user);
 this.service.DeleteData(user).subscribe((result:any)=>{
    if(result.affectedRows>0)
    {
      //this.router.navigate(['/']);
      console.log("deleted successfully...!!!!");
    }
    else
    {
      this.message = "Something went wrong!";
    }
  });
}

}
