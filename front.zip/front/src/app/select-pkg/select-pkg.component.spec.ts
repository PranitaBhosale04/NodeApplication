import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectPkgComponent } from './select-pkg.component';

describe('SelectPkgComponent', () => {
  let component: SelectPkgComponent;
  let fixture: ComponentFixture<SelectPkgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectPkgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectPkgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
