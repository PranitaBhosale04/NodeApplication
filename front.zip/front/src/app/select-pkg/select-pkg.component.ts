import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-pkg',
  templateUrl: './select-pkg.component.html',
  styleUrls: ['./select-pkg.component.css']
})
export class SelectPkgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
