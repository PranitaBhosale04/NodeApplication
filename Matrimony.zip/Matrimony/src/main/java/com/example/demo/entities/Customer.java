
package com.example.demo.entities;

import java.time.LocalDate;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="customer")
public class Customer
{	
	@Id
	private int user_id;
	
	@Column
	private String name;
	
	@Column
	private String image;
	
	@JsonIgnoreProperties("customers")
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="pkg_id")
	Packge packge;
	
	@Column
	private String status;
	
	@Column
	private String religion;
	
	@Column
	private String cast;

	@Column
	private String zodiac;
	
	@Column
	private String occupation;
	
	@Column
	String education;

	@Column
	private int income;
	
	@Column
	private String blood_group;
	
	@Column 
	private LocalDate birth_date;
	
	@Column
	private String contact2;
	
	@Column
	private String state;
	
	@Column
	private String district;
	
	@Column
	private String city;
	
	@Column(length=45)
	private String street_name;
	
	@Column
	private int pincode;
	
	@Column
	private int notification;
		

	public Customer() {
		super();
	}


	public Customer(int user_id, String name, String image, Packge packge, String status, String religion, String cast,
			String zodiac, String occupation, String education, int income, String blood_group, LocalDate birth_date,
			String contact2, String state, String district, String city, String street_name, int pincode,
			int notification) {
		super();
		this.user_id = user_id;
		this.name = name;
		this.image = image;
		this.packge = packge;
		this.status = status;
		this.religion = religion;
		this.cast = cast;
		this.zodiac = zodiac;
		this.occupation = occupation;
		this.education = education;
		this.income = income;
		this.blood_group = blood_group;
		this.birth_date = birth_date;
		this.contact2 = contact2;
		this.state = state;
		this.district = district;
		this.city = city;
		this.street_name = street_name;
		this.pincode = pincode;
		this.notification = notification;
	}


	public int getUser_id() {
		return user_id;
	}


	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public Packge getPackge() {
		return packge;
	}


	public void setPackge(Packge packge) {
		this.packge = packge;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getReligion() {
		return religion;
	}


	public void setReligion(String religion) {
		this.religion = religion;
	}


	public String getCast() {
		return cast;
	}


	public void setCast(String cast) {
		this.cast = cast;
	}


	public String getZodiac() {
		return zodiac;
	}


	public void setZodiac(String zodiac) {
		this.zodiac = zodiac;
	}


	public String getOccupation() {
		return occupation;
	}


	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}


	public String getEducation() {
		return education;
	}


	public void setEducation(String education) {
		this.education = education;
	}


	public int getIncome() {
		return income;
	}


	public void setIncome(int income) {
		this.income = income;
	}


	public String getBlood_group() {
		return blood_group;
	}


	public void setBlood_group(String blood_group) {
		this.blood_group = blood_group;
	}


	public LocalDate getBirth_date() {
		return birth_date;
	}


	public void setBirth_date(LocalDate birth_date) {
		this.birth_date = birth_date;
	}


	public String getContact2() {
		return contact2;
	}


	public void setContact2(String contact2) {
		this.contact2 = contact2;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getDistrict() {
		return district;
	}


	public void setDistrict(String district) {
		this.district = district;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getStreet_name() {
		return street_name;
	}


	public void setStreet_name(String street_name) {
		this.street_name = street_name;
	}


	public int getPincode() {
		return pincode;
	}


	public void setPincode(int pincode) {
		this.pincode = pincode;
	}


	public int getNotification() {
		return notification;
	}


	public void setNotification(int notification) {
		this.notification = notification;
	}


	@Override
	public String toString() {
		return "Customer [user_id=" + user_id + ", name=" + name + ", image=" + image + ", packge=" + packge
				+ ", status=" + status + ", religion=" + religion + ", cast=" + cast + ", zodiac=" + zodiac
				+ ", occupation=" + occupation + ", education=" + education + ", income=" + income + ", blood_group="
				+ blood_group + ", birth_date=" + birth_date + ", contact2=" + contact2 + ", state=" + state
				+ ", district=" + district + ", city=" + city + ", street_name=" + street_name + ", pincode=" + pincode
				+ ", notification=" + notification + "]";
	}

	
	


	

	
	
	
	
	
	
	
}
