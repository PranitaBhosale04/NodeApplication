
package com.example.demo.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entities.Customer;
import com.example.demo.repos.CustomerRepository;
import com.example.demo.services.CustomerService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CustomerController {
	@Autowired
	CustomerService cs;
	@Autowired
	CustomerRepository cr;
	
	@GetMapping("/allCustomer")
	public List<Customer> getAllCustomers()
	{
		System.out.println("all users data fetched ");
		return cs.findAllCustomer();
	}
	
	@GetMapping("/getCustomer")
	public Customer getById(@RequestParam("user_id")int id)
	{
		System.out.println("Get all Customer data");
		return cs.getCustomerById(id);
		
	}
	
	@GetMapping("/getCustomerByName")
	public Customer getByName(@RequestParam("name")String nm)
	{
		System.out.println("Get all data");
		return cs.getCustomerByName(nm);
		
	}
	@GetMapping("/getCustomerByCity")
	public Customer getByCity(@RequestParam("city")String city)
	{
		System.out.println("Get all data");
		return cs.getCustomerByCity(city);
		
	}
	@GetMapping("/getCustomerByOccu")
	public Customer getByOccupation(@RequestParam("occu")String occu)
	{
		System.out.println("Get all data");
		return cs.getCustomerByOccupation(occu);
		
	}
	
	@PostMapping("/insertCust")
	public int insertCustomer(@RequestBody Customer customer1)
	{
		return cs.insertC(customer1);
	}

	
	@PutMapping("/updateCust")
	public Customer updateCustomer(@RequestParam("user_id")int id,@RequestBody Customer c)
	{
		Customer cust=cr.getOne(id);
		
		cust.setName(c.getName());
		cust.setImage(c.getImage());
		cust.setPackge(c.getPackge());
		cust.setState(c.getState());
		cust.setDistrict(c.getDistrict());
		cust.setCity(c.getCity());
		cust.setStreet_name(c.getStreet_name());
		cust.setPincode(c.getPincode());
		cust.setReligion(c.getReligion());
		cust.setCast(c.getCast());
		cust.setStatus(c.getStatus());
		cust.setEducation(c.getEducation());
		cust.setOccupation(c.getOccupation());
		cust.setBlood_group(c.getBlood_group());
		cust.setBirth_date(c.getBirth_date());
		cust.setZodiac(c.getZodiac());
		cust.setContact2(c.getContact2());
		cust.setIncome(c.getIncome());
		cust.setNotification(c.getNotification());
		
		Customer customer = cr.save(cust);
		return customer;
		 
	}
	
	@DeleteMapping("/deleteCust")
	public void deleteCustomer(@RequestParam("user_id")int id)
	{
		Customer cust=cr.getOne(id);
		cr.delete(cust);
	}
}
