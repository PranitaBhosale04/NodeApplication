package com.example.demo.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Admin;
import com.example.demo.entities.Customer;
import com.example.demo.entities.UserRegistration;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Integer> 
{
	@Query(value = "SELECT * FROM admin WHERE name = :name", nativeQuery = true)
	public Admin adminLogin(@Param("name") String name);
}
