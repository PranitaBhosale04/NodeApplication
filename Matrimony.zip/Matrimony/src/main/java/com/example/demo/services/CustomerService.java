package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Customer;
import com.example.demo.repos.CustomerRepository;

@Service
public class CustomerService {
	/*@Autowired
	CustomerRepository crepo;
	
	public Customer getCustomerById(int id)
	{
		Optional<Customer> c=crepo.findById(id);
		Customer cr;
		try
		{
			cr=c.get();
		}
		catch(NoSuchElementException e)
		{
			cr=null;
		}
		return cr;
	}
	
	public int insertC(Customer c)
	{
		Customer cr=crepo.save(c);
		return cr.getUser_id();
	}
	
	public List<Customer> findAllCustomer()
	{
		return (List<Customer>)crepo.findAll();
	}*/
	
	@Autowired
	CustomerRepository crepo;
	
	public List<Customer> findAllCustomer()
	{
		return (List<Customer>)crepo.findAll();
	}
	
	public Customer getCustomerById(int id)
	{
		Optional<Customer> c=crepo.findById(id);
		Customer cr;
		try
		{
			cr=c.get();
		}
		catch(NoSuchElementException e)
		{
			cr=null;
		}
		return cr;
	}
	
	public Customer getCustomerByName(String nm)
	{
		java.util.List<Customer> c=crepo.findByName(nm);
		Customer cr;
		try
		{
			cr=c.get(0);
		}
		catch(NoSuchElementException e)
		{
			cr=null;
		}
		return cr;
	}
	public Customer getCustomerByCity(String city)
	{
		List<Customer> c=crepo.findByCity(city);
		Customer cr;
		try
		{
			cr=c.get(0);
		}
		catch(NoSuchElementException e)
		{
			cr=null;
		}
		return cr;
	}
	public Customer getCustomerByOccupation(String occu)
	{
		List<Customer> c=crepo.findByOccupation(occu);
		Customer cr;
		try
		{
			cr= c.get(0);
		}
		catch(NoSuchElementException e)
		{
			cr=null;
		}
		return cr;
	}
	
	
	public int insertC(Customer customer1)
	{
		Customer cr=crepo.save(customer1);
		return cr.getUser_id();
	}

}
