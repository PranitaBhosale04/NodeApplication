package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entities.UserRegistration;
import com.example.demo.repos.UserRegistrationRepository;
import com.example.demo.services.UserRegistrationService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/UserRegistration")
public class UserRegistrationController
{
	@Autowired
	UserRegistrationService urService;
	
	@Autowired
	UserRegistrationRepository urRepos;
	
	@GetMapping("/all")
	public List<UserRegistration> getAll()
	{
		return urService.getAll();
	}
	@GetMapping("/getById")
	public UserRegistration GetUserById(@RequestParam("user_id")int id)
	{
		return urService.getUserById(id);
	}
	
	@PostMapping(value="/save")
	public UserRegistration insert(@RequestBody UserRegistration user)
	{
		//System.out.println("###################################"+user.getName());
		return urService.saveUser(user);
	}
	
	
	@PutMapping(value="/update")
	public UserRegistration updateUser(@RequestParam("user_id")int id,@RequestBody UserRegistration u)
	{
		UserRegistration user=urService.getUserById(id);
		user.setName(u.getName());
		user.setEmail(u.getEmail());
		user.setPassword(u.getPassword());
		user.setConfirm_password(u.getConfirm_password());
		user.setContact1(u.getContact1());
		user.setGender(u.getGender());
		user.setRegistration_charges(u.getRegistration_charges());
		return urRepos.save(user);
	}
	
	@GetMapping("/login")
	public UserRegistration userLogin(@RequestParam String name, @RequestParam String password)
	{
		UserRegistration user = urRepos.userLogin(name);
		if(user != null)
			return user;
		else 
			return new UserRegistration();
	}
	
	@DeleteMapping("/deleteUser")
	public void deleteUser(@RequestParam("user_id")int id)
	{
		UserRegistration user=urRepos.getOne(id);
		urRepos.delete(user);
	}
	
	
	@GetMapping("/count")
	public long getAllCount()
	{
		return urService.getAllCount();
	}
}
