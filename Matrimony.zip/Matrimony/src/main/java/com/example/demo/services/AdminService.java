/*package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Admin;
import com.example.demo.entities.Customer;
import com.example.demo.entities.UserRegistration;
import com.example.demo.repos.AdminRepository;
import com.example.demo.repos.UserRegistrationRepository;

@Service
public class AdminService
{
	@Autowired
	AdminRepository aRepos;
	
	@Autowired
	UserRegistrationRepository urRepos;
	
	@Autowired
	Customer cRepos;
	
	public Optional<UserRegistration> getUserById(int id)
	{
		return urRepos.findById(id);
	}
	
	public List<UserRegistration> getAll()
	{
		return urRepos.findAll();
	}
	
	public List<UserRegistration> getAllu()
	{
		return urRepos.findAll();
	}
	
	/*public Customer getUserById(int id)
	{
		Optional<Customer>c=cRepos.findById(id);
		Customer cr=null;
		try
		{
			cr=c.get();
		}
		catch(NoSuchElementException e)
		{
			cr=null;
		}
		return ur;
	}
	
	public Admin adminLogin(String name) {
		return aRepos.adminLogin(name);
	}
}*/

