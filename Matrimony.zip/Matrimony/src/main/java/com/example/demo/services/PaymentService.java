/*package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Payment;

import com.example.demo.repos.PaymentRepository;

@Service
public class PaymentService 
{
	@Autowired
	PaymentRepository payRepos;

	public List<Payment> getAllP()
	{
		return payRepos.findAll();
	}
	
	public Payment save(Payment p)
	{
		return payRepos.save(p);
	}
	public Payment getPaymentById(int id)
	{
		Optional<Payment>p=payRepos.findById(id);
		Payment pp=null;
		try
		{
			pp=p.get();
		}
		catch(NoSuchElementException e)
		{
			pp=null;
		}
		return pp;
	}
}
*/