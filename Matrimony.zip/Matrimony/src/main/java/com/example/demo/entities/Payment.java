/*package com.example.demo.entities;

import java.time.LocalDate;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

@Entity
@Table(name="Payment")
public class Payment 
{
	@Id
	private int pay_id;
	
	@Column
	private LocalDate payment_date;
	
	@Column
	private int total;

	@ManyToOne
	@JoinColumn(name="user_id")
	UserRegistration user;
	
	
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Payment(int pay_id, LocalDate payment_date, int total, UserRegistration user) 
	{
		super();
		this.pay_id = pay_id;
		this.payment_date = payment_date;
		this.total = total;
		this.user = user;
		
	}

	public int getPay_id() {
		return pay_id;
	}

	public void setPay_id(int pay_id) {
		this.pay_id = pay_id;
	}

	public LocalDate getPayment_date() {
		return payment_date;
	}

	public void setPayment_date(LocalDate payment_date) {
		this.payment_date = payment_date;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public UserRegistration getUser() {
		return user;
	}

	public void setUser(UserRegistration user) {
		this.user = user;
	}

	

	@Override
	public String toString() {
		return "Payment [pay_id=" + pay_id + ", payment_date=" + payment_date + ", total=" + total + ", user=" + user
				+ "]";
	}

	
	
	
	
}*/
