package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.UserRegistration;
import com.example.demo.repos.UserRegistrationRepository;

@Service
public class UserRegistrationService 
{
	@Autowired
	UserRegistrationRepository urRepos;
	
	public List<UserRegistration> getAll()
	{
		return urRepos.findAll();
	}
	
	public long getAllCount()
	{
		
		return urRepos.count();	
	}
	public UserRegistration saveUser(UserRegistration u)
	{
		//u.set
		return urRepos.save(u);
	}
	
	public UserRegistration getUserById(int id)
	{
		Optional<UserRegistration>u=urRepos.findById(id);
		UserRegistration ur=null;
		try
		{
			ur=u.get();
		}
		catch(NoSuchElementException e)
		{
			ur=null;
		}
		return ur;
	}
	
	/*public UserRegistration saveUpdateUser(UserRegistration u)
	{
		UserRegistration user=null;
		user.setName(u.getName());
		user.setEmail(u.getEmail());
		user.setPassword(u.getPassword());
		user.setConfirm_password(u.getConfirm_password());
		user.setContact1(u.getContact1());
		user.setGender(u.getGender());
		user.setRegistration_charges(u.getRegistration_charges());
		return urRepos.save(u);
	}*/
	/*public UserRegistration delete(UserRegistration u)
	{
		return urRepos.deleteById(id);
	}*/
}
