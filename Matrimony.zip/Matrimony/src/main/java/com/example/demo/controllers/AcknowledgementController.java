package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entities.Acknowledgement;
import com.example.demo.repos.AcknowledgementRepository;
import com.example.demo.services.AcknowledgementServices;


@CrossOrigin(origins="http://localhost:4200")
@RestController
public class AcknowledgementController {
	
	@Autowired
	AcknowledgementServices aservice;
	
	@Autowired
	AcknowledgementRepository arepo;
	
	@GetMapping("/allAck")
	public List<Acknowledgement> getAllAck()
	{
		return aservice.findAllAck();
	}
	
	@PostMapping(value="/saveAck")
	public Acknowledgement saveAckn(@RequestBody Acknowledgement Ackn)
	{
		return aservice.saveAc(Ackn);
	}
	
	@GetMapping("/getAckById")
	public Acknowledgement getBySrNo(@RequestParam("sr_no")int id)
	{
		return aservice.getAckById(id);
		
	}
	
	@GetMapping("/getAckByEmail")
	public Acknowledgement getByEmailStatus(@RequestParam("email_status")int es)
	{
		return aservice.getAckById(es);
		
	}
	
	@PutMapping("/updateAck")
	public Acknowledgement updateAck(@RequestParam("sr_no")int id,@RequestBody Acknowledgement a)
	{
		Acknowledgement ack=arepo.getOne(id);
				
		ack.setSender_eid(a.getSender_eid());
		ack.setReceiver_eid(a.getReceiver_eid());
		ack.setDate(a.getDate());
		ack.setEmail_status(a.getEmail_status());

		Acknowledgement ak= arepo.save(ack);
		return ak;
		 
	}
	
	@DeleteMapping("/deleteAck")
	public void deleteAck(@RequestParam("sr_no")int id)
	{
		Acknowledgement ack=arepo.getOne(id);
		arepo.delete(ack);
	}
	
	
}
	
		
	
	
	
