package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Customer;
import com.example.demo.entities.Packge;
import com.example.demo.repos.PackgeRepository;

@Service
public class PackgeService {
	@Autowired
	PackgeRepository prepo;
	
	
	public List<Packge> findAllPackge()
	{
		return (List<Packge>)prepo.findAll();
	}
	
	public Packge getPackge(int pkg_id)
	{
		Optional<Packge>p =prepo.findById(pkg_id);
		Packge pkg=null;
		try
		{
			pkg=p.get();
		}
		catch(NoSuchElementException e)
		{
			pkg=null;
		}
		return pkg;
	}

	public int insertPkg1(Packge p)
	{
		Packge pkg=prepo.save(p);
		return pkg.getPkg_id();
	}
	
}
