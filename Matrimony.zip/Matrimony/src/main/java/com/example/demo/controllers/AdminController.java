package com.example.demo.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Admin;
import com.example.demo.entities.Customer;
import com.example.demo.entities.UserRegistration;
import com.example.demo.repos.AdminRepository;
import com.example.demo.repos.CustomerRepository;
import com.example.demo.services.CustomerService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class AdminController 
{
	@Autowired
	CustomerService cService;
	@Autowired
	CustomerRepository cRepos;
	@Autowired
	AdminRepository aRepos;

	
	@GetMapping("/viewProfile")
	public Customer getcService(@RequestParam("cust_id")int id)
	{
		System.out.println("#############################Get all Customer data");

		return	cService.getCustomerById(id);
		
	}
	
	@GetMapping("/viewReport")
	public List<Customer> getcService1()
	{
		return cService.findAllCustomer();
	}
	
	@DeleteMapping("/deleteProfile")
	public void deleteProfile(@RequestParam("cust_id")int id)
	{
		Customer c=cService.getCustomerById(id);
		cRepos.delete(c);
	}
	
	@GetMapping("/adminLogin")
	public Admin adminLogin(@RequestParam String name, @RequestParam String password)
	{
		Admin admin = aRepos.adminLogin(name);
		if(admin != null)
			return admin;
		else 
			return new Admin();
	}
}
	
