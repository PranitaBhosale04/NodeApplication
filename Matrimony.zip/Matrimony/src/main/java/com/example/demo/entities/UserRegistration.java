package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="user_registration")
public class UserRegistration
{
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private int user_id;
	
	@Column
	private String name;
	
	@Column (unique = true)
	private String password;
	
	@Column
	private String confirm_password;
	
	@Column
	private String email;
	
	@Column
	private String create_profile_for;
	
	@Column
	private String gender;
	
	@Column
	private String contact1;

	@Column 
	private int registration_charges;
	
	
	
	public UserRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserRegistration(String name, String password, String confirm_password, String email,
			String create_profile_for, String gender, String contact1, int registration_charges) {
		super();
		
		this.name = name;
		this.password = password;
		this.confirm_password = confirm_password;
		this.email = email;
		this.create_profile_for = create_profile_for;
		this.gender = gender;
		this.contact1 = contact1;
		this.registration_charges = registration_charges;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirm_password() {
		return confirm_password;
	}

	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCreate_profile_for() {
		return create_profile_for;
	}

	public void setCreate_profile_for(String create_profile_for) {
		this.create_profile_for = create_profile_for;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContact1() {
		return contact1;
	}

	public void setContact1(String contact1) {
		this.contact1 = contact1;
	}

	public int getRegistration_charges() {
		return registration_charges;
	}

	public void setRegistration_charges(int registration_charges) {
		this.registration_charges = registration_charges;
	}

	@Override
	public String toString() {
		return "UserRegistraion [user_id=" + user_id + ", name=" + name + ", password=" + password
				+ ", confirm_password=" + confirm_password + ", email=" + email + ", create_profile_for="
				+ create_profile_for + ", gender=" + gender + ", contact1=" + contact1 + ", registration_charges="
				+ registration_charges + "]";
	}

	

	
	
	
}
