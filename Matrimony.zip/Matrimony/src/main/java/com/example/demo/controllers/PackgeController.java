package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Customer;
import com.example.demo.entities.Packge;
import com.example.demo.repos.PackgeRepository;
import com.example.demo.services.PackgeService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class PackgeController {

	@Autowired
	PackgeService ps;
	@Autowired
	PackgeRepository pr;
	
	
	@GetMapping("/getAll")
	public List<Packge> getAllPackge()
	{
		System.out.println("all pkg data fetched ");
		return ps.findAllPackge();
	}
	
	@GetMapping("/getPkg")
	public Packge getPackge(@RequestParam("pkg_id")int id)
	{
		return ps.getPackge(id);
	}
	
	@PostMapping("/insertPkg")
	public int insertPkg(@RequestBody Packge p)
	{
		return ps.insertPkg1(p);
	}
	
	@PutMapping("/updatePkg")
	public Packge updatePackage(@RequestParam("pkg_id")int id,@RequestBody Packge p)
	{
		Packge pkg=pr.getOne(id);
		pkg.setPkg_name(p.getPkg_name());
		pkg.setAmount(p.getAmount());
		pkg.setExtra_charges(p.getExtra_charges());
		pkg.setValidity(p.getValidity());

		Packge pk = pr.save(pkg);
		return pk;
		 
	}
	
	@DeleteMapping("/deletePkg")
	public void deletePackge(@RequestParam("pkg_id")int id)
	{
		Packge pkg=pr.getOne(id);
		pr.delete(pkg);
	}
}
