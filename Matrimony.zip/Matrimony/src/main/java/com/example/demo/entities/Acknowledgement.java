package com.example.demo.entities;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Acknowledgement")
public class Acknowledgement {
	
	@Id
	private int sr_no;
	@Column
	private String sender_eid;
	@Column
	private String receiver_eid;
	@Column
	private LocalDate date;
	@Column
	private int email_status;
	
	public Acknowledgement() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Acknowledgement(int sr_no, String sender_eid, String receiver_eid, LocalDate date, int email_status) {
		super();
		this.sr_no = sr_no;
		this.sender_eid = sender_eid;
		this.receiver_eid = receiver_eid;
		this.date = date;
		this.email_status = email_status;
	}

	public int getSr_no() {
		return sr_no;
	}
	public void setSr_no(int sr_no) {
		this.sr_no = sr_no;
	}
	public String getSender_eid() {
		return sender_eid;
	}
	public void setSender_eid(String sender_eid) {
		this.sender_eid = sender_eid;
	}
	public String getReceiver_eid() {
		return receiver_eid;
	}
	public void setReceiver_eid(String receiver_eid) {
		this.receiver_eid = receiver_eid;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getEmail_status() {
		return email_status;
	}
	public void setEmail_status(int email_status) {
		this.email_status = email_status;
	}
	

}
