package com.example.demo.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.UserRegistration;

@Repository
public interface UserRegistrationRepository extends JpaRepository<UserRegistration,Integer>
{
	@Query(value = "SELECT * FROM user_registration WHERE name = :name", nativeQuery = true)
	public UserRegistration userLogin(@Param("name") String name);

	/*@Query("SELECT COUNT(u) FROM user_registration u")
    Long countUsers();*/
}
