package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.Acknowledgement;
import com.example.demo.repos.AcknowledgementRepository;

@Service
public class AcknowledgementServices {
	
	@Autowired
	AcknowledgementRepository Arepo;
	
	public Acknowledgement saveAc(Acknowledgement a) 
	{
		return Arepo.save(a);
	}

	public List<Acknowledgement> findAllAck()
	{
		
		return (List<Acknowledgement>)Arepo.findAll();
	}

	public Acknowledgement getAckById(int id)
	{
		Optional<Acknowledgement> c=Arepo.findById(id);
		Acknowledgement ar;
		try
		{
			ar=c.get();
		}
		catch(NoSuchElementException e)
		{
			ar=null;
		}
		return ar;
	}

	public Acknowledgement getByEmail_status(int es)
	{
		Optional<Acknowledgement> c=Arepo.findById(es);
		Acknowledgement ar;
		try
		{
			ar=c.get();
		}
		catch(NoSuchElementException e)
		{
			ar=null;
		}
		return ar;
		
	}
	
	
	
	

	
	

}
