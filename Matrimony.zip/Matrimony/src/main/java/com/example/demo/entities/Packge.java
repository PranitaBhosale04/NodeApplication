package com.example.demo.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="packge")
public class Packge {
	
	@Id
	int pkg_id;
	
	@Column
	String pkg_name;
	
	@Column
	int validity;
	
	@Column
	int amount;
	
	@Column
	int extra_charges;
	
	@JsonIgnoreProperties("packge")
	@OneToMany(mappedBy="packge")
	Set<Customer> customers=new HashSet<>();
	
	
	 /*@OneToOne
	 @MapsId
	 @JoinColumn(name = "pkg_id")
	 private Payment payment;*/

	public Packge() {
		super();
	}

	public Packge(int pkg_id, String pkg_name, int validity, int amount, int extra_charges, Set<Customer> customers) {
		super();
		this.pkg_id = pkg_id;
		this.pkg_name = pkg_name;
		this.validity = validity;
		this.amount = amount;
		this.extra_charges = extra_charges;
		this.customers = customers;
		//this.payment = payment;
	}

	public int getPkg_id() {
		return pkg_id;
	}

	public void setPkg_id(int pkg_id) {
		this.pkg_id = pkg_id;
	}

	public String getPkg_name() {
		return pkg_name;
	}

	public void setPkg_name(String pkg_name) {
		this.pkg_name = pkg_name;
	}

	public int getValidity() {
		return validity;
	}

	public void setValidity(int validity) {
		this.validity = validity;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getExtra_charges() {
		return extra_charges;
	}

	public void setExtra_charges(int extra_charges) {
		this.extra_charges = extra_charges;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

	

	/*public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}*/

	@Override
	public String toString() {
		return "Packge [pkg_id=" + pkg_id + ", pkg_name=" + pkg_name + ", validity=" + validity + ", amount=" + amount
				+ ", extra_charges=" + extra_charges + ", customers=" + customers + "]";
	}

		
	
	
	
	
	
	

}
