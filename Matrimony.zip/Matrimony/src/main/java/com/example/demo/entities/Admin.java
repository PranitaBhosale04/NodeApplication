package com.example.demo.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="admin")
public class Admin
{
	@Id
	private int aid;
	
	/*@OneToMany(mappedBy = "admin",
	cascade = CascadeType.ALL)
	private Set<UserRegistration> userregistration;*/
	 
	
	@Column
	private String name;
	@Column
	private String password;
	
	@Column
	private String email_id;
	@Column
	private String contact_no;
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Admin(int aid, String name, String password, String email_id,
			String contact_no) {
		super();
		this.aid = aid;
		this.name = name;
		this.password = password;
		this.email_id = email_id;
		this.contact_no = contact_no;
	}


	public int getAid() {
		return aid;
	}


	public void setAid(int aid) {
		this.aid = aid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getEmail_id() {
		return email_id;
	}


	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}


	public String getContact_no() {
		return contact_no;
	}


	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}


	@Override
	public String toString() {
		return "Admin [aid=" + aid + ", name=" + name + ", password="
				+ password + ", email_id=" + email_id + ", contact_no=" + contact_no + "]";
	}

	
	
	
}
